import React,{Component} from 'react'
import Firstpage from './components/Firstpage'
import Startpage from './components/Startpage'
import Secpage from './components/Secpage'
import { motion } from 'framer-motion'
import Result from './components/Result'
import sooldata from './components/sool_data.json'
import axios from 'axios'
import Thirdpage from './components/Thirdpage'
import Anjoopage from './components/Anjoopage'
var selecteddosu=-1
var postdosu=-1
var posttaste=-1
var posttansan=-1
var postcond=-1
var postcond2=-1
var postbob=-1
var email=null
var profile=null
var id=null
var postimp=-1
var postimp2=-1
var testtype=0

class App extends Component
{
  constructor(props)
  {
    super(props)
    this.state={
      login_inform:['로그인 해주세요','https://www.fabriziorocca.it/guide/wp-content/uploads/2018/03/thumb_14400082930User.png','asd'],
      data:'loading',
      page:0,
      selectedcardid2:[],
      selectedcardid:[
      ],
      
    }
  }
  onNextpage=function(){
    this.setState(
      {
        page:this.state.page+1,
        selectedcardid:this.state.selectedcardid,
      }
    )
  }.bind(this)

  onSelectedCard=function(_list){
    this.setState(
      {
        selectedcardid:_list
      }
    )}.bind(this)
    onSelectedCard2=function(_list){
      this.setState(
        {
          selectedcardid2:_list
        }
      )}.bind(this)


  render(){
    var idlist=this.state.selectedcardid
    var tastelist=[]
    for(var idx=0;idx<idlist.length;idx+=1)
    {
      tastelist=tastelist.concat(sooldata[idlist[idx]+528])
    }
   
    
    
  





    var _page=null
    if(this.state.page===1)
    {
      _page=
      
      <Firstpage
      loginf={this.state.login_inform}
      _onNextpage={function(){
        if(this.state.selectedcardid==0)
        {
          alert('1개 이상 선택해주세요!')
        }
        else{
        this.setState(
          {
            page:this.state.page+1,
            selectedcardid:this.state.selectedcardid,
          }
        )
        }
      }.bind(this)}
      _onSelectedCard={this.onSelectedCard}
      ></Firstpage>

    }
    else if(this.state.page===0)
    {
      _page=

      <Startpage
      loginf={this.state.login_inform}
      _onLoginpost={function(inf){
         email=inf['email']
         id=inf['givenName']
         profile=inf['imageUrl']
        this.setState(
          {
            login_inform:[email,profile,id],
            data:this.state.data,
            page:this.state.page,
            selectedcardid:this.state.selectedcardid,
          }
        )
    
        }.bind(this)}
      _onNextpage={this.onNextpage}></Startpage>


    }
    else if(this.state.page===3)
    {
      _page=<Thirdpage
      loginf={this.state.login_inform}
      _page_level={this.state.page}
      _q_list={[
        {
            issel: 0,
            q_id: 1,
            q_name:'저도수(1%~10%)'
        },
        {
            issel: 0,
            q_id: 2,
            q_name:'중도수(11%~20%)'
        },
        {
            issel: 0,
            q_id: 3,
            q_name:'고도수(20%~)'
        },
        
      ] }
      _question='선호하는 도수를 골라주세요!'
      _onNextpage={this.onNextpage}
      _onDosuchange={function(dosu){selecteddosu=dosu



      for(var i=0;i<selecteddosu.length;i++)
      {
        if(selecteddosu[i]['issel']==1)
        {
          postdosu=i
        }
      }
      
    }}
      
  
  ></Thirdpage>



    }
    else if(this.state.page===2)
    {
      _page=

      <Secpage
      loginf={this.state.login_inform}
      _page_level={this.state.page}
      _q_list={[
        {
            issel: 0,
            q_id: 1,
            q_name:'과일 향'
        },
        {
            issel: 0,
            q_id: 2,
            q_name:'곡물 향'
        },
        {
            issel: 0,
            q_id: 3,
            q_name:'달달한 향'
        },
        {
          issel: 0,
          q_id: 4,
          q_name:'자연의 향'
      },
      {
        issel: 0,
        q_id: 5,
        q_name:'약재 향'
    }
      ] }
      _question='선호하는 향을 골라주세요!'
      _onNextpage={this.onNextpage}
      _onDosuchange={function(dosu){selecteddosu=dosu
        

      for(var i=0;i<selecteddosu.length;i++)
      {
        if(selecteddosu[i]['issel']==1)
        {
          posttaste=i
        }
      }
      
    }}
     ></Secpage>

    }
    else if(this.state.page===5) 
    {
      _page=
      <Thirdpage
      loginf={this.state.login_inform}
      _page_level={this.state.page}
      _q_list={[
        {
            issel: 0,
            q_id: 1,
            q_name:'혼자'
        },
        {
            issel: 0,
            q_id: 2,
            q_name:'같이'
        },
      
      ] }
      _question='같이 마시나요?'
      _onNextpage={this.onNextpage}
      _onDosuchange={function(dosu){selecteddosu=dosu
 

      for(var i=0;i<selecteddosu.length;i++)
      {
        if(selecteddosu[i]['issel']==1)
        {
          postcond=i
        }
      }
      
    }}
     ></Thirdpage>
    }
    else if(this.state.page===6) 
    {
      _page=
      <Secpage
      loginf={this.state.login_inform}
      _page_level={this.state.page}
      _q_list={[
        {
            issel: 0,
            q_id: 1,
            q_name:'홈술'
        },
        {
            issel: 0,
            q_id: 2,
            q_name:'밖술'
        },
      
      ] }
      _question='어디서 드시나요?'
      _onNextpage={this.onNextpage}
      _onDosuchange={function(dosu){selecteddosu=dosu


      for(var i=0;i<selecteddosu.length;i++)
      {
        if(selecteddosu[i]['issel']==1)
        {
          postcond2=i
        }
      }
      
    }}
     ></Secpage>


    }

      else if(this.state.page===4 ) 
    {
      _page=
      <Secpage
      loginf={this.state.login_inform}
      _page_level={this.state.page}
      _q_list={[
        {
            issel: 0,
            q_id: 1,
            q_name:'없음'
        },
        {
          issel: 0,
          q_id: 2,
          q_name:'중간'
      },
        {
            issel: 0,
            q_id: 3,
            q_name:'많음'
        },
       
      ] }
      _question='탄산의 포함 여부를 골라주세요!'
      _onNextpage={this.onNextpage}
      _onDosuchange={function(dosu){selecteddosu=dosu
    

      for(var i=0;i<selecteddosu.length;i++)
      {
        if(selecteddosu[i]['issel']==1)
        {
          posttansan=i
        }
      }
      
    }}
     ></Secpage>
    }
  
  else if(this.state.page===8) 
  {
    _page=
    <Secpage
    /*_onPostdata={function(){
      axios.post('http://192.168.0.4:5000/home',
    {
      "인기주류":tastelist,
      "도수":postdosu,
      "맛":posttaste,
      "탄산":posttansan,
      "상황":postcond,
      "밥":postbob,
    })
    .then(function (response) {
      console.log(response.data)
        this.setState({
    
          data: response.data['result'],
    
        })
    }.bind(this))
    }.bind(this)
    } */
    loginf={this.state.login_inform}
    _page_level={this.state.page}
    _q_list={[
      {
          issel: 0,
          q_id: 1,
          q_name:'술자체가 중요하다'
      },
      {
          issel: 0,
          q_id: 2,
          q_name:'안주가 중요하다'
      },
    
    
    ] }
    _question='나는 술을 고를 때'
    _onNextpage={this.onNextpage}
    _onDosuchange={function(dosu){selecteddosu=dosu



    for(var i=0;i<selecteddosu.length;i++)
    {
      if(selecteddosu[i]['issel']==1)
      {
        postimp=i
      }
    }
    
  }}
   ></Secpage>
  }
  else if(this.state.page===9) 
  {
    _page=
    <Thirdpage
    
    loginf={this.state.login_inform}
    _page_level={this.state.page}
    _q_list={[
      {
          issel: 0,
          q_id: 1,
          q_name:'먹던거 먹을래'
      },
      {
          issel: 0,
          q_id: 2,
          q_name:'새로운거 먹을래'
      },
      {
        issel: 0,
        q_id: 3,
        q_name:'전문가의 추천'
    },
    {
      issel: 0,
      q_id: 4,
      q_name:'싼 거'
  },
  {
    issel: 0,
    q_id: 5,
    q_name:'패키지 이쁜 거'
},
    
    ] }
    _question='나는 술을 고를 때2?'
    _onNextpage={this.onNextpage}
    _onDosuchange={function(dosu){selecteddosu=dosu


    for(var i=0;i<selecteddosu.length;i++)
    {
      if(selecteddosu[i]['issel']==1)
      {
        postimp2=i
      }
    }
    
  }}
  _onPostdata={function(){
    if(postcond==0)
      if(postcond2==0)
        if(postimp==0)
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=0
          else
            testtype=1
        else
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=2
          else
            testtype=3
      else
        if(postimp==0)
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=4
          else
            testtype=5
        else
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=6
          else
            testtype=7
    else
      if(postcond2==0)
        if(postimp==0)
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=8
          else
            testtype=9
        else
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=10
          else
            testtype=11
      else
        if(postimp==0)
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=12
          else
            testtype=13
        else
          if(postimp2==0 || postimp2==2 || postimp2==0)
            testtype=14
          else
            testtype=15
      
      


    


    axios.post('https://projw.pythonanywhere.com//home',
  {
    "인기주류":tastelist,
    "도수":postdosu,
    "맛":posttaste,
    "탄산":posttansan,
    "상황":postcond,
    "밥":postbob,
    "안주":this.state.selectedcardid2,
    "중요도1":postimp,
    "중요도2":postimp2,
  })
  .then(function (response) {
    console.log(response.data['result'])
   
      this.setState({
  
        data: response.data['result'],
        
  
      })
  }.bind(this))
  }.bind(this)
  }
   ></Thirdpage>
}
else if(this.state.page===7) 
{
  _page=
  <Anjoopage

  _onDosuchange={function(){
    console.log(1)
  }}
  
loginf={this.state.login_inform}
      _onNextpage={function(){
        if(this.state.selectedcardid2==0)
        {
          alert('1개 이상 선택해주세요!')
        }
        else{
        this.setState(
          {
            page:this.state.page+1,
            selectedcardid2:this.state.selectedcardid2,
          }
        )
        }
      }.bind(this)}
      _onSelectedCard={this.onSelectedCard2}
/*_onPostdata={function(){
  axios.post('http://10.64.133.29:5000/home',
{
  "인기주류":tastelist,
  "도수":postdosu,
  "맛":posttaste,
  "탄산":posttansan,
  "상황":postcond,
  "밥":postbob,
  "안주":this.state.selectedcardid2
})
.then(function (response) {
  console.log(response.data)
    this.setState({

      data: response.data['result'],

    })
}.bind(this))
}.bind(this)
} */
 ></Anjoopage> 
}

    else if(this.state.page===10)
    {
 
      _page=<Result 
      _testtype={testtype}
      loginf={this.state.login_inform}
      postdata={this.state.data}

     
    ></Result>
    }

    return(
      <div>
      {_page}
      </div>
    )
  }
}
export default App
