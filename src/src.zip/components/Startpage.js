import React,{Component} from 'react'
import Upbar from './Upbar'
import logo1 from './logo1.jpg'
import Nextbtn from './Nextbtn'
import { motion } from 'framer-motion'
import Sharebtn from './Sharebtn'

class Startpage extends Component
{

  render(){

    return(

      <div className='container' >
      <Upbar _page={0} _loginf={this.props.loginf}></Upbar>
      <motion.div
      initial={{x:-500}}
      animate={{x:0}}>
      <h1>대충 시작페이지0.12</h1>
      <img src={logo1} className='logo'></img>
      <Nextbtn
      _pagelevel={1}
      onLoginpost={this.props._onLoginpost}
      onNextpage={this.props._onNextpage}></Nextbtn>
        
      </motion.div>
     </div>




    )
  }
}
export default Startpage