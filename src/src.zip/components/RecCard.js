import React,{Component} from 'react'
import Bar_com from './Bar_com'

import Horibar from './Horibar'
import sooldata from './sool_data.json'
import tagdata from './tagdata.json'

class RecCard extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            
            imghover:0
        }
    }
    render()
    
    { 
        var _imgsrc=this.props.imgsrc
        var _imgname=this.props.imgname
        var _rank=this.props.rank
        var _id=this.props.id
        
        return(
            <div className='rankbox'>

                <div className='rankrowgrid'>
                <div className='zxc'>{_rank}위</div>
                <img src={_imgsrc}
                className='borderimage'
                
                >
                </img>
                <div className={this.state.imghover? 'hoverrank':'rank'}><div className='imgnamepad'>{_imgname}{sooldata[_id]['가격']}</div></div>
                <div className='btnhoverrange'
                onClick={function(){
                    this.props.onClickCircle()
                }.bind(this)}
                onMouseOver={function(){
                    this.setState(
                        {
                            imghover:1
                        }
                    )
                }.bind(this)}
                onMouseOut={function(){
                    this.setState(
                        {
                            imghover:0
                        }
                    )
                }.bind(this)}></div>

                </div>
                
                
                <div className='barrowgrid'>
                <Horibar id={_id}></Horibar>
                
                
                
                
                <div className='taggrid'>
                    {tagdata["tag"][_id].map((tags)=><div className='tagbox'>{tags}</div>)}
                </div>
                <div className='shoppingbtn'
                
                onClick={function(){

                    window.open('https://msearch.shopping.naver.com/search/all?query='+sooldata[_id]['상품명'], '_blank')}
            }>
                <div>네이버 쇼핑</div>
                </div>

                    

                
                
                </div>
                <Bar_com id={_id}></Bar_com>
                

            </div>
           
  
           
       

        )
    }

}
export default RecCard