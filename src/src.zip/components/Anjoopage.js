import React,{Component} from 'react'
import Grid from '@material-ui/core/Grid'
import Upbar from './Upbar'
import AnjooList  from './AnjooList'
import Nextbtn from './Nextbtn'
import { motion } from 'framer-motion'

class Anjoopage extends Component
{
  constructor(props)
  {
    super(props)
    this.state={
      selectedidlist:[]
    }
  }

  render(){


    return(
      <div className='container' >
      <Upbar _page={1} _loginf={this.props.loginf}></Upbar>
      <motion.div
      initial={{x:-500}}
      animate={{x:0}}>
      <Grid
      container
      direction='row'
      justifyContent='center'
      >
      <div className='step'>
        <div>STEP7</div>
        </div>
      <h3 className='step_question'>선호하는 안주를 선택하세요(최대3개)</h3>
      </Grid>
      <AnjooList onChangelist={this.props._onSelectedCard}></AnjooList>
      <Nextbtn onDosuchange={this.props._onDosuchange} _pagelevel={1} onNextpage={this.props._onNextpage}></Nextbtn>
      </motion.div>
      </div>
     
    )
    }
  
}
export default Anjoopage