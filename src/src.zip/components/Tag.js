import React, {Component} from 'react'
class Tag extends Component
{
    render()
    {
        return(
            <div className='tag'>
             <div className='coloredtext'>술이름</div>
            
            </div>

        )
    }
}
export default Tag